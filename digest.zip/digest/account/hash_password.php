<?php
require '../classes/database.class.php'; 

$query = "SELECT account_id, password FROM accounts";
$stmt = $conn->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($users as $user) {
    $hashedPassword = password_hash($user['password'], PASSWORD_DEFAULT);

    $updateQuery = "UPDATE accounts SET password = :hashedPassword WHERE account_id = :account_id";
    $updateStmt = $conn->prepare($updateQuery);
    $updateStmt->bindParam(':hashedPassword', $hashedPassword);
    $updateStmt->bindParam(':account_id', $user['account_id']);
    $updateStmt->execute();
}

echo "Passwords have been successfully hashed!";
?>
