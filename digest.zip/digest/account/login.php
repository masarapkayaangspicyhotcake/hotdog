<?php
session_start();
require '../classes/account.class.php'; // Make sure this path is correct

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['pass'];

    $account = new Account();
    $user = $account->login($username, $password);

    if ($user) {
        $_SESSION['user_id'] = $user['account_id'];
        $_SESSION['username'] = $user['user_name'];
        $_SESSION['role'] = $user['role'];

        echo json_encode(['status' => 'success', 'message' => 'Login successful!', 'redirect' => '../superadmin/dashboard.php']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid username or password.']);
    }
}
?>
