<!-- PEKE, UNSURE -->
<?php
include '../classes/database.class.php';
session_start();

if(isset($_POST['submit'])) {
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
    $pass = sha1($_POST['password']);
    $pass = filter_var($pass, FILTER_SANITIZE_STRING);
    $verification_code = mt_rand(100000, 999999); 

    // Check if email already exists
    $check_email = $conn->prepare("SELECT * FROM `accounts` WHERE email = ?");
    $check_email->execute([$email]);

    if ($check_email->rowCount() > 0) {
        $message = 'Email already exists!';
    } else {
        // Insert new user
        $insert_user = $conn->prepare("INSERT INTO `accounts` (name, email, password, role, verification_code) VALUES (?, ?, ?, 'user', ?)");
        $insert_user->execute([$name, $email, $pass, $verification_code]);

        $_SESSION['email'] = $email;
        $_SESSION['verification_code'] = $verification_code;
        header('location: verify.php'); // Redirect to verification page
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | University Digest</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="h-screen flex items-center justify-center bg-gray-100">

    <div class="flex w-full h-screen">

        <!-- Left Section (Full Height) -->
        <div class="hidden md:flex w-1/2 bg-gradient-to-br from-maroon-700 to-yellow-500 p-10 flex-col justify-center items-center text-white">
            <h2 class="text-4xl font-bold mb-4 text-yellow-500">Join University Digest</h2>
            <p class="text-lg text-center max-w-md text-yellow-500">Stay updated with the latest news, events, and discussions.</p>        </div>

        <!-- Right Section (Full Height Form) -->
        <div class="w-full md:w-1/2 flex flex-col justify-center items-center px-10 bg-white">
            <h2 class="text-3xl font-bold text-gray-800 mb-6">Create an Account</h2>

            <?php if(isset($message)) echo "<p class='text-red-500 text-sm mb-4'>$message</p>"; ?>

            <form action="" method="post" class="space-y-4 w-full max-w-sm">
                <div>
                    <label class="block text-gray-700 font-medium mb-1">Full Name</label>
                    <input type="text" name="name" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500" placeholder="Enter your full name" required>
                </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-1">Email</label>
                    <input type="email" name="email" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500" placeholder="Enter your email" required>
                </div>

                <div>
                    <label class="block text-gray-700 font-medium mb-1">Password</label>
                    <div class="relative">
                        <input type="password" name="password" id="password" class="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 pr-10" placeholder="Enter your password" required>
                        <button type="button" onclick="togglePassword()" class="absolute top-3 right-3 text-gray-500">
                            👁️
                        </button>
                    </div>
                </div>

                <button type="submit" name="submit" class="w-full bg-maroon-700 text-white p-3 rounded-lg hover:bg-maroon-800 transition">Register</button>

                <div class="text-center">
                    <p class="text-gray-600">or</p>
                    <button type="button" class="w-full bg-white border p-3 rounded-lg flex items-center justify-center space-x-2 hover:bg-gray-200 transition">
                        <img src="../img/logogoogle.png" class="w-5 h-5">
                        <span>Continue with Google</span>
                    </button>
                </div>

                <p class="text-center text-gray-600">Already have an account? <a href="login.html   " class="text-yellow-600 font-medium hover:underline">Login now</a></p>
            </form>
        </div>

    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById("password");
            passwordField.type = passwordField.type === "password" ? "text" : "password";
        }
    </script>

</body>
</html>
