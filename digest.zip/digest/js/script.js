// search
$(document).ready(function(){
    $("#search").on("keyup", function(){
        let query = $(this).val();
        if (query.length > 2) {
            $.ajax({
                url: "search.php",
                method: "POST",
                data: { search: query },
                success: function(data){
                    $("#search-results").html(data).show();
                }
            });
        } else {
            $("#search-results").hide();
        }
    });

    $(document).click(function(event) {
        if (!$(event.target).closest('.search-box').length) {
            $("#search-results").hide();
        }
    });
});



// carousel
let currentIndex = 0;
const slides = document.querySelectorAll(".carousel-item");
const indicators = document.querySelectorAll(".indicator");

function updateCarousel() {
    document.querySelector(".carousel-inner").style.transform = `translateX(-${currentIndex * 100}%)`;
    indicators.forEach((ind, i) => ind.classList.toggle("active", i === currentIndex));
}

function moveSlide(step) {
    currentIndex = (currentIndex + step + slides.length) % slides.length;
    updateCarousel();
}

function goToSlide(index) {
    currentIndex = index;
    updateCarousel();
}

// Auto-slide every 4 seconds
setInterval(() => moveSlide(1), 4000);


//USER DASHBOARD 
$(document).ready(function () {
    loadCarousel();
    loadAnnouncements();
    loadArticles();
    loadMagazines();
    loadTejidos();
});

// Load carousel images
function loadCarousel() {
    $.ajax({
        url: "./ajax/fetch_carousel.php",
        method: "GET",
        success: function (data) {
            $("#carousel-images").html(data.images);
            $("#carousel-indicators").html(data.indicators);
        },
        dataType: "json"
    });
}

// Load announcements
function loadAnnouncements() {
    $.ajax({
        url: "./ajax/fetch_announcements.php",
        method: "GET",
        success: function (data) {
            $("#announcements").html(data);
        }
    });
}

// Load articles
function loadArticles() {
    $.ajax({
        url: "./ajax/fetch_articles.php",
        method: "GET",
        success: function (data) {
            $("#articles").html(data);
        }
    });
}

// Load magazines
function loadMagazines() {
    $.ajax({
        url: "./ajax/fetch_magazines.php",
        method: "GET",
        success: function (data) {
            $("#magazines").html(data);
        }
    });
}

// Load tejidos
function loadTejidos() {
    $.ajax({
        url: "./ajax/fetch_tejidos.php",
        method: "GET",
        success: function (data) {
            $("#tejidos").html(data);
        }
    });
}