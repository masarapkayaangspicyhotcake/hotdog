function togglePassword() {
    const passwordField = document.getElementById("password");
    const eyeIcon = document.getElementById("eyeIcon");
    if (passwordField.type === "password") {
        passwordField.type = "text";
        eyeIcon.classList.remove("bi-eye-slash");
        eyeIcon.classList.add("bi-eye");
    } else {
        passwordField.type = "password";
        eyeIcon.classList.remove("bi-eye");
        eyeIcon.classList.add("bi-eye-slash");
    }
}
document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent default form submission

        const formData = new FormData(loginForm);

        fetch("/digest/account/login.php", { // Ensure correct path
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            console.log("Response Data:", data); // Debugging

            if (data.status === "success") {
                console.log("Redirecting to:", data.redirect); // Debugging

                setTimeout(() => {
                    window.location.href = data.redirect;
                }, 1000); // Shorter delay for better UX
            } else {
                document.getElementById("response").innerHTML = `<p class="text-lg text-red-600">${data.message}</p>`;
            }
        })
        .catch(error => console.error("Fetch Error:", error));
    });
});
