<div class="sidebar flex-column flex-shrink-0">
    <a href="/digest/superadmin/dashboard" class="logo">
        <img class="img-fluid" src="../imgs/logo.png" alt="" srcset="">
        <img class="img-fluid" src="../imgs/logoname.png" alt="" srcset="">
    </a>
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="side-nav-title">Home</li>
        <li class="nav-item">
        <a href="/digest/superadmin/dashboard" id="dashboard-link" class="nav-link">
        <i class="bi bi-speedometer2"></i>
                <span class="fs-6 ms-2">Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="/digest/superadmin/archives" class="nav-link" id="archive-link">
                <i class="bi bi-archive"></i>
                <span class="fs-6 ms-2">Archives</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-activity"></i>
                <span class="fs-6 ms-2">Activity Logs</span>
            </a>
        </li>
        <li class="side-nav-title">Posts</li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-plus"></i>
                <span class="fs-6 ms-2">Add Post</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-card-text"></i>
                <span class="fs-6 ms-2">View Post</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-chat-left-quote-fill"></i>
                <span class="fs-6 ms-2">See comments</span>
            </a>
        </li>
        <li class="side-nav-title">Accounts</li>
        <li class="nav-item">
            <a href="products" id="products-link" class="nav-link">
                <i class="bi bi-person-check"></i>
                <span class="fs-6 ms-2">Admins</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-person"></i>
                <span class="fs-6 ms-2">Profile</span>
            </a>
        </li>
        <li>
            <a href="../account/logout.php" class="nav-link">
                <i class="bi bi-box-arrow-right"></i>
                <span class="fs-6 ms-2">Log out</span>
        </li>
    </ul>
<div>
<!-- <button id="openSidebarBtn" class="btn btn-primary" onclick="toggleSidebar()"><i class="bi bi-list"></i></button>  -->

</div>
</div>