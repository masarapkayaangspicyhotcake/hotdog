<?php
require 'database.class.php';

if (isset($_POST['search'])) {
    $query = $_POST['search'];
    
    $stmt = $conn->prepare("SELECT title FROM posts WHERE title LIKE ?");
    $searchTerm = "%{$query}%";
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>" . htmlspecialchars($row['title']) . "</p>";
        }
    } else {
        echo "<p>No results found</p>";
    }
}
?>