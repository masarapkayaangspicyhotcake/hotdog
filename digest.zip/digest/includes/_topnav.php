<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The University Digest</title>
    <link rel="stylesheet" href="../css/_topnav.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&icon_names=search" />
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
<header>
    <div class="logo-container">
        <img src="../imgs/logo.png" alt="The University Digest Logo">
        <div class="logo"><h1>The University Digest</h1></div>
    </div>
    
    <div class="search-box">
        <input type="text" name="search" id="search" placeholder="Search">
        <button type="submit"><span class="material-symbols-outlined">search</span></button>
        <div id="search-results"></div>
    </div>

    <ul>
        <li><a href="../users/userdashboard.php">Home</a></li>
        <li><a href="#">Categories</a>
            <ul class="dropdown">
                <li><a href="#">Education</a></li>
                <li><a href="#">Sports</a></li>
                <li><a href="#">Entertainment</a></li>
            </ul>
        </li>
        <li><a href="#">Authors</a></li>
        <li><a href="#">About Us</a></li>
        <li><a href="#"><img src="../imgs/acc.png" alt="User Account" class="user-icon"></a>
            <ul class="dropdown">
                <li><a href="../account/login.html">Sign In</a></li>
                <li><a href="#">Sign Up</a></li>
            </ul></li>
    </ul>
</header>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>