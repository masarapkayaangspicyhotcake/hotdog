<?php
include_once __DIR__ . '/../includes/_topnav.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/userdashboard.css">
</head>
<body>
    <div class="main-content">
    <div class="carousel-container">
        <div class="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="../imgs/1slide.png" alt="Slide 1">
                </div>
                <div class="carousel-item">
                    <img src="../imgs/2slide.png" alt="Slide 2">
                </div>
                <div class="carousel-item">
                    <img src="../imgs/3slide.png" alt="Slide 3">
                </div>
            </div>

            <button class="carousel-control prev" onclick="moveSlide(-1)">&#10094;</button>
            <button class="carousel-control next" onclick="moveSlide(1)">&#10095;</button>

            <div class="carousel-indicators">
                <span class="indicator active" onclick="goToSlide(0)"></span>
                <span class="indicator" onclick="goToSlide(1)"></span>
                <span class="indicator" onclick="goToSlide(2)"></span>
            </div>
        </div>
    </div>
<br> <br>
    <div class="card-container">
    <div class="card">
        <h5 class="card-header">Announcements</h5>
        <div class="card-body">
            <a href="#" class="btn">View More</a>
        </div>
    </div>
</div>


<div class="card-container">
    <div class="card">
        <h5 class="card-header">Articles</h5>
        <div class="card-body">
            <a href="#" class="btn">View Now</a>
        </div>
    </div>
</div>


<div class="card-container">
    <div class="card">
        <h5 class="card-header">Magazines</h5>
        <div class="card-body">
            <a href="#" class="btn">View Now</a>
        </div>
    </div>
</div>


<div class="card-container">
    <div class="card">
        <h5 class="card-header">Tejidos</h5>
        <img src="../imgs/tejidos.jpg" alt="Tejidos Image" class="card-img4">
        <div class="card-body">
        <a href="../contents/tejidos.php" class="btn">View Now</a>
        </div>
    </div>
</div>
</div>
    <script src="../js/script.js"></script>
</body>
</html>