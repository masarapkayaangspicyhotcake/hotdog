<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Archives</h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card p-4">
                <div class="d-flex card-header justify-content-between align-items-center w-100 px-2">
                    <h3 class="header-title mb-0">Archived Posts</h3>
                </div>
                <div class="card-body p-1 pt-2">
                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Title & Date</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Campus Life: A Day in the University</h5>
                                        <span class="text-muted font-13">07 April 2024</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info">Campus News</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-warning">Archived</span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-light"><i class="bi bi-eye"></i></button>
                                        <button class="btn btn-sm btn-primary"><i class="bi bi-arrow-counterclockwise"></i></button>
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Student Success Stories</h5>
                                        <span class="text-muted font-13">25 March 2024</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-success">Student Life</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-warning">Archived</span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-light"><i class="bi bi-eye"></i></button>
                                        <button class="btn btn-sm btn-primary"><i class="bi bi-arrow-counterclockwise"></i></button>
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Academic Excellence Guide</h5>
                                        <span class="text-muted font-13">17 March 2024</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary">Academics</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-warning">Archived</span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-light"><i class="bi bi-eye"></i></button>
                                        <button class="btn btn-sm btn-primary"><i class="bi bi-arrow-counterclockwise"></i></button>
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Research Opportunities</h5>
                                        <span class="text-muted font-13">12 March 2024</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary">Research</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-warning">Archived</span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-light"><i class="bi bi-eye"></i></button>
                                        <button class="btn btn-sm btn-primary"><i class="bi bi-arrow-counterclockwise"></i></button>
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Campus Events Calendar</h5>
                                        <span class="text-muted font-13">05 March 2024</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-info">Events</span>
                                    </td>
                                    <td>
                                        <span class="badge bg-warning">Archived</span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-light"><i class="bi bi-eye"></i></button>
                                        <button class="btn btn-sm btn-primary"><i class="bi bi-arrow-counterclockwise"></i></button>
                                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>