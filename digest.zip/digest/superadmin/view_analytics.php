<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Dashboard</h4>
                <div class="page-title-right">
                    <form class="d-flex">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-light" id="dash-daterange">
                            <span class="input-group-text bg-primary border-primary text-white brand-bg-color">
                                <i class="bi bi-calendar3"></i>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 col-md-12 col-lg-12 col-xl-12 d-flex flex-column">
            <div class="row flex-grow-1">
                <div class="col-12 col-sm-6 col-md-6 col-xl-3 pb-4">
                    <div class="card widget-flat mb-0">
                        <div class="card-body">
                            <div class="float-end me-2">
                                <i class="bi bi-people fs-1  brand-color"></i>
                            </div>
                            <h5 class="text-muted fw-normal mt-0" title="Number of Students">Students</h5>
                            <h3 class="my-3">36,254</h3>
                            <p class="mb-0 text-muted">
                                <span class="text-success me-2"><i class="bi bi-arrow-up"></i> 5.27%</span>
                            </p>
                            <p class="mb-0 text-muted pt-2">
                                <span class="text-nowrap">Since last semester</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-6 col-xl-3 pb-4">
                    <div class="card widget-flat mb-0">
                        <div class="card-body">
                            <div class="float-end me-2">
                                <i class="bi bi-file-text fs-1  brand-color"></i>
                            </div>
                            <h5 class="text-muted fw-normal mt-0" title="Number of Posts">Posts</h5>
                            <h3 class="my-3">5,543</h3>
                            <p class="mb-0 text-muted">
                                <span class="text-danger me-2"><i class="bi bi-arrow-down"></i></i> 1.08%</span>
                            </p>
                            <p class="mb-0 text-muted pt-2">
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-6 col-xl-3 pb-4">
                    <div class="card widget-flat mb-0">
                        <div class="card-body">
                            <div class="float-end me-2">
                                <i class="bi bi-graph-up fs-1  brand-color"></i>
                            </div>
                            <h5 class="text-muted fw-normal mt-0" title="Average Views">Views</h5>
                            <h3 class="my-3">6,254</h3>
                            <p class="mb-0 text-muted">
                                <span class="text-danger me-2"><i class="bi bi-arrow-down"></i></i> 7.00%</span>
                            </p>
                            <p class="mb-0 text-muted pt-2">
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-6 col-xl-3 pb-4">
                    <div class="card widget-flat mb-0">
                        <div class="card-body">
                            <div class="float-end me-2">
                                <i class="bi bi-graph-up-arrow fs-1  brand-color"></i>
                            </div>
                            <h5 class="text-muted fw-normal mt-0" title="Growth">Engagement</h5>
                            <h3 class="my-3">+ 30.56%</h3>
                            <p class="mb-0 text-muted">
                                <span class="text-success me-2"><i class="bi bi-arrow-up"></i></i> 4.87%</span>
                            </p>
                            <p class="mb-0 text-muted pt-2">
                                <span class="text-nowrap">Since last month</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-12 col-lg-12 col-xl-12">
            <div class="card card-h-100 p-3">
                <div class="d-flex card-header justify-content-between align-items-center w-100">
                    <h3 class="header-title mb-0">Posts By Month</h3>
                    <div class="dropdown">
                        <a href="#" class="dropdown-toggle arrow-none card-drop" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-three-dots-vertical brand-color fs-3"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a href="javascript:void(0);" class="dropdown-item">Export Report</a>
                        </div>
                    </div>
                </div>
                <canvas id="postsChart" class="card-body"></canvas>
            </div>
        </div>
        <div class="col-12">
            <div class="card p-4">
                <div class="d-flex card-header justify-content-between align-items-center w-100 px-2">
                    <h3 class="header-title mb-0">Top Performing Posts</h3>
                </div>
                <div class="card-body p-1 pt-2">
                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap table-hover mb-0">
                            <tbody>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Campus Life: A Day in the University</h5>
                                        <span class="text-muted font-13">07 April 2024</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">4.8</h5>
                                        <span class="text-muted font-13">Rating</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">8,234</h5>
                                        <span class="text-muted font-13">Views</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">1,243</h5>
                                        <span class="text-muted font-13">Comments</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Student Success Stories</h5>
                                        <span class="text-muted font-13">25 March 2024</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">4.7</h5>
                                        <span class="text-muted font-13">Rating</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">7,129</h5>
                                        <span class="text-muted font-13">Views</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">982</h5>
                                        <span class="text-muted font-13">Comments</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Academic Excellence Guide</h5>
                                        <span class="text-muted font-13">17 March 2024</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">4.6</h5>
                                        <span class="text-muted font-13">Rating</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">6,845</h5>
                                        <span class="text-muted font-13">Views</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">876</h5>
                                        <span class="text-muted font-13">Comments</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Research Opportunities</h5>
                                        <span class="text-muted font-13">12 March 2024</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">4.5</h5>
                                        <span class="text-muted font-13">Rating</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">5,932</h5>
                                        <span class="text-muted font-13">Views</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">754</h5>
                                        <span class="text-muted font-13">Comments</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">Campus Events Calendar</h5>
                                        <span class="text-muted font-13">05 March 2024</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">4.4</h5>
                                        <span class="text-muted font-13">Rating</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">5,621</h5>
                                        <span class="text-muted font-13">Views</span>
                                    </td>
                                    <td>
                                        <h5 class="font-14 my-1 fw-normal">632</h5>
                                        <span class="text-muted font-13">Comments</span>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div> <!-- end table-responsive-->
                </div>
            </div>
        </div>
    </div>
</div>