<?php
$page_title = "University Digest - Dashboard";
session_start();

// Debugging: Check what session variables exist
// echo '<pre>';
// print_r($_SESSION);
// echo '</pre>';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'superadmin') {
    header('location: ../account/login.html');
    exit();
}


require_once '../includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="../css/style.css"> 
    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Optional Bootstrap JS (needed for offcanvas & dropdown functionality) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body id="dashboard">
    <div class="wrapper">
        <?php
        require_once '../includes/sidebar.php';
        ?>
        <div class="content-page px-3">
            
            <!-- dynamic content here -->
        </div>
    </div>
    <?php
    require_once '../includes/footer.php';

    ?>

    
</body>
</html>
